﻿function pruebaObtenerContador() {
    console.log('JS pruebaObtenerContador');
    
    DotNet.invokeMethodAsync("PeliculasBlazor.Client", "ObtenerCurrentCount")
        .then(resultado => {
            console.log('Contador desde JS: ' + resultado);
        }
    );
}

function pruebaLlamarIncremento(elemento) {
    elemento.invokeMethodAsync("IncrementCount");
}