﻿using BlazorPeliculas.Client.Repositorios;
using BlazorPeliculas.Shared.Entidades;

namespace BlazorPeliculas.Client.Repositorios
{
    public class Repositorio : IRepositorio
    {
        public List<Pelicula> ObtenerPeliculas()
        {
            return new List<Pelicula>
            {
               new Pelicula {titulo ="Wakanda Forever",
                             fechaLanzamiento = new DateTime(2023, 02, 11),
                             portada= Pelicula.getPortada("wakanda.png")},
               new Pelicula {titulo ="Moana",
                             fechaLanzamiento = new DateTime(2016, 11, 23),
                             portada= Pelicula.getPortada("moana.png")},
               new Pelicula {titulo ="Inception", fechaLanzamiento = new DateTime(2010, 08, 06),
                             portada=Pelicula.getPortada("inception.png")}
            };
        }
    }
}
