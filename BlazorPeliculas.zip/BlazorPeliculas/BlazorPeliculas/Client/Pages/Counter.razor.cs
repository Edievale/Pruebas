﻿using MathNet.Numerics.Statistics;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;

namespace BlazorPeliculas.Client.Pages
{
    // Tiene que ser partical para que puedan convivir como una única clase las dos partes: razor y razor.cs
    public partial class Counter
    {
        private string titulo = "Contador";
        private int currentCount = 0;
        [Inject] public IJSRuntime js { get; set; } = null!;

        public async Task IncrementCount()
        {
            currentCount++;
            var arreglo = new double[] { 1, 2, 3, 4, 5, 6, 7 };
            var maximo = arreglo.Maximum();
            var minimo = arreglo.Minimum();

            await js.InvokeVoidAsync("alert", $"Mínimo:{minimo} y Máximo:{maximo}");
        }
    }
}
