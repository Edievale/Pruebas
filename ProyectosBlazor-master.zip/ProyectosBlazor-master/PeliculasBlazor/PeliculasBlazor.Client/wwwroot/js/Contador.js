﻿export function mostrarAlerta (mensaje) {
    console.log('JS mostrarAlerta');
    alert(mensaje);
}