﻿namespace PeliculasBlazor.Shared.Entidades
{
    public class Pelicula
    {
        public string titulo { get; set; } = null!;
        public DateTime fechaLanzamiento { get; set; }
    }
}
