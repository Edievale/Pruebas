﻿namespace PeliculasBlazor.Shared
{
    // PeliculasBlazor.Shared es un Proyecto de Biblioteca de Clases
    public class Informacion
    {

    }
}