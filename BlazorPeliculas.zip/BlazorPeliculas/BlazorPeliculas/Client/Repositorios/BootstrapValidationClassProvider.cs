﻿using Microsoft.AspNetCore.Components.Forms;

namespace BlazorPeliculas.Client.Repositorios
{
    public class BootstrapValidationClassProvider : FieldCssClassProvider
    {
        public override string GetFieldCssClass(EditContext editContext, in FieldIdentifier fieldIdentifier)
        {
            if (editContext == null)
            {
                throw new ArgumentNullException(nameof(editContext));
            }

            if (!editContext.IsModified())
            {
                return string.Empty;
            }

            //bool isValid = !editContext.GetValidationMessages(fieldIdentifier).Any();

            //return isValid ? "is-valid" : "is-invalid";

            var isValid = !editContext.GetValidationMessages(fieldIdentifier).Any();
            if (editContext.IsModified(fieldIdentifier))
            {
                return isValid ? "is-valid" : "is-invalid";
            }
            return isValid ? "" : "is-invalid";

        }
    }
}
