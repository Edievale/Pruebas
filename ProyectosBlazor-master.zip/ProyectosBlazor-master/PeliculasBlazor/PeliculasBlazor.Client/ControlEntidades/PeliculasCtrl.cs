﻿using Newtonsoft.Json;
using PeliculasBlazor.Client;
using PeliculasBlazor.Shared.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
//_Imports.razor

namespace PeliculasBlazor.Client.ControlEntidades
{
    public class PeliculasCtrl
    {
        public static List<Pelicula> ObtenerPeliculas()
        {
            List<Pelicula> result = new List<Pelicula>();

            try
            {
                
                string path = @"/Data/InfoPeliculas.json";
                string fullPath = Path.GetFullPath(path);
                StreamReader r = new StreamReader(path);
                string jsonString = r.ReadToEnd();
                result = JsonConvert.DeserializeObject<List<Pelicula>>(jsonString)!;
                



                return result!;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ERROR:{ex.Message}");
                return null!;
            }
        }
    }
}
