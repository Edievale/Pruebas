﻿using System.Reflection;

namespace PeliculasBlazor.Shared.Entidades
{
    public class Pelicula
    {
        public string titulo { get; set; } = null!;
        public DateTime fechaLanzamiento { get; set; }
        public string portada { get; set; } = null!;

        public string tituloTruncado
        {
            get
            {
                if (string.IsNullOrWhiteSpace(titulo))
                {
                    return null!;
                }
                else if (titulo.Length >= 20)
                {
                    return titulo.Substring(0, 17) + "...";
                }
                else
                {
                    return titulo;
                }
            }
        }
        public static string getPortada(string namefile)
        {
            string ruta = $"{Path.GetDirectoryName(Assembly.GetEntryAssembly()?.Location)}/img/{namefile}";
            return ruta;

        }
    }
}
