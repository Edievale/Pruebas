﻿using Microsoft.JSInterop;

namespace BlazorPeliculas.Client.Utilities
{
    public static class IJSRuntimeExtensionsMethods
    {
        public static async ValueTask<bool> Corfirmacion(this IJSRuntime js, string mensaje)
        {
            // Existe funciones de JS que no devuelven nada
            await js.InvokeVoidAsync("console.log", "Prueba de Console log mediante JS.");

            // Funciones que devuelven un valor como esta
            return await js.InvokeAsync<bool>("confirm", mensaje); // Función determinada que se llama "confirm"
        }
    }
}
