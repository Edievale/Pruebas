﻿using CurrieTechnologies.Razor.SweetAlert2;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.JSInterop;
using BlazorPeliculas.Client.Repositorios;
using BlazorPeliculas.Shared.Entidades;


namespace BlazorPeliculas.Client.Pages.Generos
{
    partial class FormularioGenero
    {
        [EditorRequired][Parameter] public Genero eGenero { get; set; } = null!;
        [EditorRequired][Parameter] public EventCallback eValidSubmit { get; set; }
        private EditContext editContext = null!;
        public bool formularioPosteado { get; set; } = false;
        //[Inject] public IJSRuntime js { get; set; } = null!;
        [Inject] public SweetAlertService sweetAS { get; set; } = null!;

        protected override void OnInitialized()
        {
            editContext = new(eGenero);
            editContext.SetFieldCssClassProvider(new BootstrapValidationClassProvider());
        }

        private async Task OnBeforeNav(LocationChangingContext context)
        {
            try
            {
                // No permite salir sin guardar.

                // Esto no me funciona
                var formularioEsEditado = editContext.IsModified();

                if (!formularioEsEditado)
                {
                    return;
                }

                if (formularioPosteado)
                {
                    return;
                }

                //var confirmado = js.InvokeAsync<bool>("confirm", "¿Deseas abandonar la página y perder los cambios?");
                SweetAlertOptions swOpt = new SweetAlertOptions();
                swOpt.Title = "Confirmación";
                swOpt.Text = "¿Deseas abandornar la página y perder los cambios?";
                swOpt.Icon = SweetAlertIcon.Warning;
                swOpt.ShowCancelButton = true;
                swOpt.ConfirmButtonText = "Aceptar";
                swOpt.CancelButtonText = "Cancelar";

                SweetAlertResult resultado = await sweetAS.FireAsync(swOpt);

                var confirmado = !string.IsNullOrEmpty(resultado.Value);

                if (confirmado)
                {
                    return;
                }

                context.PreventNavigation(); // Para impedir que el usuario salga de la página.
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
