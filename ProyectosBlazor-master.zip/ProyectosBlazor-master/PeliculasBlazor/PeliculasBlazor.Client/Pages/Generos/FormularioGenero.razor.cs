﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.JSInterop;
using PeliculasBlazor.Shared.Entidades;
using System.Reflection;


namespace PeliculasBlazor.Client.Pages.Generos
{
    partial class FormularioGenero
    {
        [EditorRequired][Parameter] public Genero eGenero { get; set; } = null!;
        [EditorRequired][Parameter] public EventCallback onValidSubmit { get; set; }
        private EditContext editContext = null!;
        public bool formularioPosteado { get; set; } = false;
        [Inject] public IJSRuntime js { get; set; } = null!;

        protected override void OnInitialized()
        {
            editContext = new EditContext(eGenero);
        }

        private async Task OnBeforeNav(LocationChangingContext context)
        {
            // No permite salir sin guardar.
            var formularioEsEditado = editContext.IsModified();

            if (!formularioEsEditado)
            {
                return;
            }

            if (formularioPosteado)
            {
                return;
            }

            var confirmado = js.InvokeAsync<bool>("confirm", "¿Deseas abandonar la página y perder los cambios?");

            if (confirmado.Result)
            {
                return;
            }

            context.PreventNavigation(); // Realiza la navegación
        }
    }
}
