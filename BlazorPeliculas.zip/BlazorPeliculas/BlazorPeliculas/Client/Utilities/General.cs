﻿namespace BlazorPeliculas.Client.Utilities
{
    public class General
    {
        public static string tituloGeneral = "Películas App";


        public static string Mayusculas(string cadena)
        {
            return cadena.ToUpper();
        }
    }
}
