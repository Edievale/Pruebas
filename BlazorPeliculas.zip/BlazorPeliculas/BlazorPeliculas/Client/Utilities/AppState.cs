﻿namespace BlazorPeliculas
    .Client.Utilities
{
    public class AppState
    {
        public string Color { get; set; } = "red";
        public string Size { get; set; } = "12px";
        public string Mensaje { get; set; } = "Esto es una prueba de parámetros en Cascada.";
    }
}
