﻿using CurrieTechnologies.Razor.SweetAlert2;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.JSInterop;
using BlazorPeliculas.Client.Repositorios;
using BlazorPeliculas.Shared.Entidades;
using System.Reflection;


namespace BlazorPeliculas.Client.Pages.Generos
{
    partial class FormularioGenero
    {
        [EditorRequired][Parameter] public Genero eGenero { get; set; } = null!;
        [EditorRequired][Parameter] public EventCallback eValidSubmit { get; set; }
        private EditContext editContext = null!;
        public bool formularioPosteado { get; set; } = false;
        [Inject] public IJSRuntime js { get; set; } = null!;
        [Inject] public SweetAlertService sweetAS { get; set; } = null!;

        protected override void OnInitialized()
        {
            editContext = new(eGenero);
            editContext.SetFieldCssClassProvider(new BootstrapValidationClassProvider());
        }

        private async Task OnBeforeNav(LocationChangingContext context)
        {
            // No permite salir sin guardar.

            // Esto no me funciona
            var formularioEsEditado = editContext.IsModified();

            if (!formularioEsEditado)
            {
                return;
            }

            if (formularioPosteado)
            {
                return;
            }

            //var confirmado = js.InvokeAsync<bool>("confirm", "¿Deseas abandonar la página y perder los cambios?");

            SweetAlertResult resultado = await sweetAS.FireAsync(new SweetAlertOptions
            {
                Title = "Confirmación",
                Text = "¿Deseas abandornar la página y perder los cambios?",
                Icon = SweetAlertIcon.Warning,
                ShowCancelButton = true,
                ConfirmButtonText = "Aceptar",
                CancelButtonText = "Cancelar"
            });

            var confirmado = !string.IsNullOrEmpty(resultado.Value);

            if (confirmado)
            {
                return;
            }

            context.PreventNavigation(); // Para impedir que el usuario salga de la página.
        }
    }
}
