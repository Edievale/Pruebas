﻿using PeliculasBlazor.Shared.Entidades;


namespace PeliculasBlazor.Client.Repositorios
{
    public interface IRepositorio
    {
        List<Pelicula> ObtenerPeliculas();
    }
}
